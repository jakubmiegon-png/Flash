BeatFlash Web

Pliki aplikacji webowej/PWA.

WAŻNE:
- Mikrofon i kamera wymagają bezpiecznego połączenia HTTPS.
- Sprzętowa latarka działa tylko, jeśli przeglądarka i telefon udostępniają constraint `torch`.
- Gdy latarka nie jest dostępna, aplikacja używa błysku ekranu.
- Najlepiej testować w aktualnym Chrome na Androidzie.

Uruchomienie:
1. Umieść te pliki na dowolnym hostingu HTTPS.
2. Otwórz stronę w Chrome.
3. Zezwól na mikrofon i kamerę.
4. Naciśnij START.
